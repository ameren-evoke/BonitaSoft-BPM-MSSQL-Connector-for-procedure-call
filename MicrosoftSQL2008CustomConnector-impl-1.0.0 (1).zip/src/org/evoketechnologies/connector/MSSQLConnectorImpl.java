/**
 * 
 */
package org.evoketechnologies.connector;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.bonitasoft.engine.connector.ConnectorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The connector execution will follow the steps 1 - setInputParameters() -->
 * the connector receives input parameters values 2 - validateInputParameters()
 * --> the connector can validate input parameters values 3 - connect() --> the
 * connector can establish a connection to a remote server (if necessary) 4 -
 * executeBusinessLogic() --> execute the connector 5 - getOutputParameters()
 * --> output are retrieved from connector 6 - disconnect() --> the connector
 * can close connection to remote server (if any)
 */
public class MSSQLConnectorImpl extends AbstractMSSQLConnectorImpl {

	private final static Logger logger = LoggerFactory
			.getLogger(MSSQLConnectorImpl.class);

	@Override
	protected void executeBusinessLogic() throws ConnectorException {
		logger.info("url ::" + getUrl());
		String employeeId = getEmployeeID();
		Connection con = null;
		CallableStatement csmt = null;
		ResultSet resultSet = null;
	
		int requestDetailId = getRequestDetailID() != null ? getRequestDetailID()
				: 0;
		logger.info("requestDetailId ::");
		int accessSecurityLevelID = getAccessSecurityLevelID() != null ? getAccessSecurityLevelID()
				: 0;
		logger.info("accessSecurityLevelID ::");
		int processID = getProcessID() != null ? getProcessID() : 0;
		logger.info("processID ::");
		List<Map<String, Object>> requestList = new ArrayList<Map<String, Object>>();
		
		logger.info("try before ::::");
		try {
			
			// converting Util date to SQL date
			Class.forName(getDriver());

			// connecting to MicroSoft SQL Server
			con = DriverManager.getConnection(getUrl(), getUsername(),
					getPassword());
			
			// to get stored procedure
			String getDBUSERCursorSql = getQuery();
			// invoke the stored procedure
			csmt = con.prepareCall(getDBUSERCursorSql);
			if (employeeId != null) {
				//to convert date to database format
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
				logger.info("getEmployeeID ::" + getEmployeeID());
				String startDate = null;
				if(getAccessStart() != null)
					{
					startDate = sdf.format(getAccessStart());
					}
				String endDate = null;
				if(getAccessEnd() != null)
				{
					endDate = sdf.format(getAccessEnd());
				}
				// input parameters for SP_CheckAccessCreds procedure
				
				csmt.setString(1, employeeId);
				csmt.setString(2,startDate);
				csmt.setString(3,endDate);
				boolean queryResult = csmt.execute();
				//logger.info("execute returned " + queryResult);
				int rowsAffected = 0;
				while (queryResult || rowsAffected != -1) {
					if (queryResult) {
						ResultSet rs = csmt.getResultSet();
						//logger.info("getResultSet returned " + rs);
						if (rs != null) {
							Map<String, Object> requestMap = new HashMap<String, Object>();
							while (rs.next()) {
								// output parameters for SP_CheckAccessCreds
								requestMap.put("AmerenSupv",
										rs.getString("AmerenSupv"));
								requestMap.put("ImmSupv",
										rs.getString("ImmSupv"));
								requestMap.put("ImmSupvCBT",
										rs.getDate("ImmSupvCBT"));
								requestMap.put("EmpNERCCBT",
										rs.getDate("EmpCBT"));
								requestMap.put("PRAValid",
										rs.getBoolean("ValidPRA"));
								
							}
							setResultSet(requestMap);
							rs.close();
						}
						
					} else {
						
						rowsAffected = csmt.getUpdateCount();
						//logger.info("getUpdateCount returned " + rowsAffected);
					}
					queryResult = csmt.getMoreResults();
					logger.info("getMoreResults returned " + queryResult);
				}
				//logger.info("resultSet 	@@@@@resultSet ::" + resultSet);
			} else if (requestDetailId > 0 && accessSecurityLevelID > 0
					&& processID > 0 && getImmSuperID() != null
					&& getModifiedby() != null) {
				logger.info("update proc  inputs  ::");
				logger.info("update proc  inputs @@@@@@@ getRequestDetailID() ::"+getRequestDetailID() );
				logger.info("update proc  inputs @@@@@@@ getAccessSecurityLevelID() ::"+getAccessSecurityLevelID() );
				logger.info("update proc  inputs @@@@@@@ getProcessID() ::"+getProcessID() );
				logger.info("update proc  inputs @@@@@@@ getImmSuperID() ::"+getImmSuperID() );
				logger.info("update proc  inputs @@@@@@@ getModifiedby() ::"+getModifiedby() );
				// input parameters for sp_SaveAccessCredsRequest procedure
				csmt.setInt(1, getRequestDetailID());
				csmt.setInt(2, getAccessSecurityLevelID());
				csmt.setInt(3, getProcessID());
				csmt.setString(4, getImmSuperID());
				csmt.setString(5, getModifiedby());
				csmt.setInt(6, 11);
				csmt.setInt(7, 11);
				csmt.setInt(8, 11);
				int executeUpdate = csmt.executeUpdate();
				logger.info("update proc  inputs  ::" +executeUpdate);
			} else {
				logger.info("resultSet  :::");
				resultSet = csmt.executeQuery();
				logger.info("resultSet after  :::");
				if (resultSet != null) {
					while (resultSet.next()) {
						logger.info("resultSet.next()  ::: ");
						Map<String, Object> requestMap = new HashMap<String, Object>();
						// output parameters for SP_RetrieveRequestDetails
						
						if(resultSet.getInt("RequestStatusID") == 10){
							logger.info("RequestStatusID if ::: ");
						requestMap.put("EmployeeNumber",
								resultSet.getString("EmployeeNumber"));
						logger.info("EmployeeNumber ::: ");
						requestMap.put("RequestDetailID",
								resultSet.getString("RequestDetailID"));
						logger.info("RequestDetailID ::: ");
						requestMap.put("AccessStartDate",
								resultSet.getDate("AccessStartDate"));
						logger.info("AccessStartDate ::: ");
						requestMap.put("AccessEndDate",
								resultSet.getDate("AccessEndDate"));
						requestMap.put("RequestDateTime",
								resultSet.getDate("RequestDateTime"));
						logger.info("AccessEndDate ::: ");
						requestMap.put("AccessRequestID",
								resultSet.getInt("AccessRequestID"));
						logger.info("AccessEndDate ::: ");
						requestMap.put("RequestorID",
								resultSet.getString("RequestorID"));
						logger.info("RequestorID ::: ");
						requestMap.put("EmpStat",
								resultSet.getString("EmpStat"));
						logger.info("EmpStat ::: ");
						requestMap.put("RoleSecLvl",
								resultSet.getString("RoleSecLvl"));
						logger.info("RoleSecLvl ::: ");
						requestMap.put("AccessSecurityLevelID",
								resultSet.getInt("LocSecLvl"));
						logger.info("AccessSecurityLevelID ::: ");
						requestMap.put("RequestStatusID",
								resultSet.getInt("RequestStatusID"));
						logger.info("RequestStatusID ::: ");
						requestMap.put("AccessLocationID",
								resultSet.getInt("AccessLocationID"));
						logger.info("AccessLocationID ::: ");
						requestMap.put("RoleGenAccess",
								resultSet.getString("RoleGenAccess"));
						logger.info("RoleGenAccess ::: ");
						requestMap.put("RoleTransAccess",
								resultSet.getString("RoleTransAccess"));
						logger.info("RoleTransAccess ::: ");							
						requestMap.put("ShortDesc",
								resultSet.getString("ShortDesc"));
						logger.info("ShortDesc ::: ");
						requestMap.put("LocationName",
								resultSet.getString("LocationName"));
						logger.info("LocationName ::: ");
						
						requestList.add(requestMap);
						logger.info("requestList size ::: " + requestList.size());
						}
						setResultSet(requestMap);
					}
				}
				
			}

		} catch (Exception e) {
			logger.info("error is msg ::: " + e.getMessage());
			throw new ConnectorException("Exception error while executing stored procedure ::"+ e.getMessage(), e);	
		} finally {
			try {
				if(csmt != null){
				csmt.close();
				}
				if(con != null){
				con.close();
				}
			} catch (SQLException e) {
				logger.error("error is ::: " + e);

			}

		}
		setListOfResultSet(requestList);
	}

	@Override
	public void connect() throws ConnectorException {
		// [Optional] Open a connection to remote server

	}

	@Override
	public void disconnect() throws ConnectorException {
		// [Optional] Close connection to remote server

	}

}
