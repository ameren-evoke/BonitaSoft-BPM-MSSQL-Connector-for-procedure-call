package org.evoketechnologies.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractMicrosoftSQL2008CustomConnectorImpl extends AbstractConnector {

	protected final static String DRIVER_INPUT_PARAMETER = "driver";
	protected final static String URL_INPUT_PARAMETER = "url";
	protected final static String USERNAME_INPUT_PARAMETER = "username";
	protected final static String PASSWORD_INPUT_PARAMETER = "password";
	protected final static String QUERY_INPUT_PARAMETER = "query";
	protected final static String INPUTLIST_INPUT_PARAMETER = "inputList";
	protected final static String CHECKMORERESULTSET_INPUT_PARAMETER = "checkMoreResultset";
	protected final String RESULTSETLIST_OUTPUT_PARAMETER = "resultSetList";
	protected final String RESULTSET_OUTPUT_PARAMETER = "resultSet";

	protected final java.lang.String getDriver() {
		return (java.lang.String) getInputParameter(DRIVER_INPUT_PARAMETER);
	}

	protected final java.lang.String getUrl() {
		return (java.lang.String) getInputParameter(URL_INPUT_PARAMETER);
	}

	protected final java.lang.String getUsername() {
		return (java.lang.String) getInputParameter(USERNAME_INPUT_PARAMETER);
	}

	protected final java.lang.String getPassword() {
		return (java.lang.String) getInputParameter(PASSWORD_INPUT_PARAMETER);
	}

	protected final java.lang.String getQuery() {
		return (java.lang.String) getInputParameter(QUERY_INPUT_PARAMETER);
	}

	protected final java.util.LinkedList getInputList() {
		return (java.util.LinkedList) getInputParameter(INPUTLIST_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getCheckMoreResultset() {
		return (java.lang.Boolean) getInputParameter(CHECKMORERESULTSET_INPUT_PARAMETER);
	}

	protected final void setResultSetList(java.util.List resultSetList) {
		setOutputParameter(RESULTSETLIST_OUTPUT_PARAMETER, resultSetList);
	}

	protected final void setResultSet(java.util.Map resultSet) {
		setOutputParameter(RESULTSET_OUTPUT_PARAMETER, resultSet);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getDriver();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("driver type is invalid");
		}
		try {
			getUrl();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("url type is invalid");
		}
		try {
			getUsername();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("username type is invalid");
		}
		try {
			getPassword();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("password type is invalid");
		}
		try {
			getQuery();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("query type is invalid");
		}
		try {
			getInputList();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("inputList type is invalid");
		}
		try {
			getCheckMoreResultset();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("checkMoreResultset type is invalid");
		}

	}

}
