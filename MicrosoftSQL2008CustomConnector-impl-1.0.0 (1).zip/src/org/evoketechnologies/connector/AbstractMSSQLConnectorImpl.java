package org.evoketechnologies.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractMSSQLConnectorImpl extends AbstractConnector {

	protected final static String DRIVER_INPUT_PARAMETER = "driver";
	protected final static String URL_INPUT_PARAMETER = "url";
	protected final static String USERNAME_INPUT_PARAMETER = "username";
	protected final static String PASSWORD_INPUT_PARAMETER = "password";
	protected final static String QUERY_INPUT_PARAMETER = "query";
	protected final static String EMPLOYEEID_INPUT_PARAMETER = "employeeID";
	protected final static String ACCESSSTART_INPUT_PARAMETER = "accessStart";
	protected final static String ACCESSEND_INPUT_PARAMETER = "accessEnd";
	protected final static String REQUESTDETAILID_INPUT_PARAMETER = "requestDetailID";
	protected final static String ACCESSSECURITYLEVELID_INPUT_PARAMETER = "accessSecurityLevelID";
	protected final static String PROCESSID_INPUT_PARAMETER = "processID";
	protected final static String IMMSUPERID_INPUT_PARAMETER = "immSuperID";
	protected final static String MODIFIEDBY_INPUT_PARAMETER = "modifiedby";
	protected final String LISTOFRESULTSET_OUTPUT_PARAMETER = "listOfResultSet";
	protected final String RESULTSET_OUTPUT_PARAMETER = "resultSet";

	protected final java.lang.String getDriver() {
		return (java.lang.String) getInputParameter(DRIVER_INPUT_PARAMETER);
	}

	protected final java.lang.String getUrl() {
		return (java.lang.String) getInputParameter(URL_INPUT_PARAMETER);
	}

	protected final java.lang.String getUsername() {
		return (java.lang.String) getInputParameter(USERNAME_INPUT_PARAMETER);
	}

	protected final java.lang.String getPassword() {
		return (java.lang.String) getInputParameter(PASSWORD_INPUT_PARAMETER);
	}

	protected final java.lang.String getQuery() {
		return (java.lang.String) getInputParameter(QUERY_INPUT_PARAMETER);
	}

	protected final java.lang.String getEmployeeID() {
		return (java.lang.String) getInputParameter(EMPLOYEEID_INPUT_PARAMETER);
	}

	protected final java.util.Date getAccessStart() {
		return (java.util.Date) getInputParameter(ACCESSSTART_INPUT_PARAMETER);
	}

	protected final java.util.Date getAccessEnd() {
		return (java.util.Date) getInputParameter(ACCESSEND_INPUT_PARAMETER);
	}

	protected final java.lang.Integer getRequestDetailID() {
		return (java.lang.Integer) getInputParameter(REQUESTDETAILID_INPUT_PARAMETER);
	}

	protected final java.lang.Integer getAccessSecurityLevelID() {
		return (java.lang.Integer) getInputParameter(ACCESSSECURITYLEVELID_INPUT_PARAMETER);
	}

	protected final java.lang.Integer getProcessID() {
		return (java.lang.Integer) getInputParameter(PROCESSID_INPUT_PARAMETER);
	}

	protected final java.lang.String getImmSuperID() {
		return (java.lang.String) getInputParameter(IMMSUPERID_INPUT_PARAMETER);
	}

	protected final java.lang.String getModifiedby() {
		return (java.lang.String) getInputParameter(MODIFIEDBY_INPUT_PARAMETER);
	}

	protected final void setListOfResultSet(java.util.List listOfResultSet) {
		setOutputParameter(LISTOFRESULTSET_OUTPUT_PARAMETER, listOfResultSet);
	}

	protected final void setResultSet(java.lang.Object resultSet) {
		setOutputParameter(RESULTSET_OUTPUT_PARAMETER, resultSet);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getDriver();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("driver type is invalid");
		}
		try {
			getUrl();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("url type is invalid");
		}
		try {
			getUsername();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("username type is invalid");
		}
		try {
			getPassword();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("password type is invalid");
		}
		try {
			getQuery();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("query type is invalid");
		}
		try {
			getEmployeeID();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("employeeID type is invalid");
		}
		try {
			getAccessStart();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"accessStart type is invalid");
		}
		try {
			getAccessEnd();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("accessEnd type is invalid");
		}
		try {
			getRequestDetailID();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"requestDetailID type is invalid");
		}
		try {
			getAccessSecurityLevelID();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"accessSecurityLevelID type is invalid");
		}
		try {
			getProcessID();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("processID type is invalid");
		}
		try {
			getImmSuperID();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("immSuperID type is invalid");
		}
		try {
			getModifiedby();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("modifiedby type is invalid");
		}

	}

}
