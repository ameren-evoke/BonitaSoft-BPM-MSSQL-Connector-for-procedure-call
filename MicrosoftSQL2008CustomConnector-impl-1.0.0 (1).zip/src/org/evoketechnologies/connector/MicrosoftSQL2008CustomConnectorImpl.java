/**
 * 
 */
package org.evoketechnologies.connector;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.bonitasoft.engine.connector.ConnectorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The connector execution will follow the steps 1 - setInputParameters() -->
 * the connector receives input parameters values 2 - validateInputParameters()
 * --> the connector can validate input parameters values 3 - connect() --> the
 * connector can establish a connection to a remote server (if necessary) 4 -
 * executeBusinessLogic() --> execute the connector 5 - getOutputParameters()
 * --> output are retrieved from connector 6 - disconnect() --> the connector
 * can close connection to remote server (if any)
 */
public class MicrosoftSQL2008CustomConnectorImpl extends
		AbstractMicrosoftSQL2008CustomConnectorImpl {
	private final static Logger logger = LoggerFactory
			.getLogger(MSSQLConnectorImpl.class);
	@Override
	protected void executeBusinessLogic() throws ConnectorException {
		// Get access to the connector input parameters

		Connection con = null;
		CallableStatement csmt = null;
		ResultSet resultSet = null;
		LinkedList inputList = getInputList();
		List<Map<String, Object>> requestList = new ArrayList<Map<String, Object>>();
		logger.info("url "+getUrl());
		try {
			// converting Util date to SQL date
			Class.forName(getDriver());
			// connecting to MicroSoft SQL Server
			con = DriverManager.getConnection(getUrl(), getUsername(),getPassword());
			// invoke the stored procedure
			csmt = con.prepareCall(getQuery());

			// setting query input's
			if (inputList != null && inputList.size()>0) {
				for (int i = 0; i < inputList.size(); i++) {
					if (inputList.get(i) instanceof String || inputList.get(i) instanceof Date ) {
						csmt.setString(i+1, (String) inputList.get(i));
					} else if (inputList.get(i) instanceof Integer ) {
						csmt.setInt(i+1, (Integer) inputList.get(i));
					} else if (inputList.get(i) instanceof Long) {
						csmt.setLong(i+1, (Integer) inputList.get(i));
					} else if (inputList.get(i) instanceof Boolean) {
						csmt.setBoolean(i+1, (Boolean)inputList.get(i));
					} else if (inputList.get(i) instanceof Double) {
						csmt.setDouble(i+1, (Double)inputList.get(i));
					}else {
						csmt.setObject(i+1,inputList.get(i));
					}
			}
			}
			if (getCheckMoreResultset()) {
				logger.info("getCheckMoreResultset  ");
				boolean queryResult = csmt.execute();
				int rowsAffected = 0;
				while (queryResult || rowsAffected != -1) {
					if (queryResult) {
						ResultSet rs = csmt.getResultSet();
						ResultSetMetaData rsMetaData = rs.getMetaData();
						int columnCount = rsMetaData.getColumnCount();
						if (rs != null) {
							Map<String, Object> requestMap = new HashMap<String, Object>();
							while (rs.next()) {
								for (int i = 0; i < columnCount; i++) {
									requestMap.put(rsMetaData.getColumnName(i + 1),rs.getObject(i + 1));
								}
								setResultSet(requestMap);
								rs.close();
							}
						}
					} else {
						rowsAffected = csmt.getUpdateCount();
					}
					queryResult = csmt.getMoreResults();
				}
			} else {
				logger.info("getCheckMoreResultset  else  "+csmt);
				resultSet = csmt.executeQuery();
				ResultSetMetaData rsMetaData = resultSet.getMetaData();
				int columnCount = rsMetaData.getColumnCount();
				if (resultSet != null) {
					while (resultSet.next()) {
						
						Map<String, Object> requestMap = new HashMap<String, Object>();
						for (int i = 0; i < columnCount; i++) {
							requestMap.put(rsMetaData.getColumnName(i + 1),resultSet.getObject(i + 1));
						}
						requestList.add(requestMap);
					}
					setResultSetList(requestList);
				}
			}
		} catch (Exception e) {
			logger.error("Exception ::  "+e.getMessage());
			setResultSet(null);
			setResultSetList(requestList);
			throw new ConnectorException("Exception error while executing stored procedure ::"+ e.getMessage(), e);			
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (csmt != null) {
					csmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
				logger.info("Exception ::  "+e);
			}
		}
	}

	@Override
	public void connect() throws ConnectorException {
		// [Optional] Open a connection to remote server

	}

	@Override
	public void disconnect() throws ConnectorException {
		// [Optional] Close connection to remote server

	}

}
